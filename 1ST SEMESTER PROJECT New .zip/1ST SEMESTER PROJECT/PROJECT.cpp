#include <time.h>
#include <SFML/Audio.hpp>
#include <SFML/Graphics.hpp>
#include <iostream>
#include <sstream>
#include <string>
#include <fstream>

using namespace sf;
using namespace std;

int ts = 54;  // tile size
Vector2i offset(48, 24);

/*
 * piece
 * A struct representing each tile in the grid:
 *  - (x, y):    Pixel coordinates
 *  - (row, col):Grid position
 *  - kind:      Tile type
 *  - match:     Matching flag
 *  - alpha:     Transparency for fade-out
 */
struct piece
{
    int x, y, row, col, kind, match, alpha;
    piece() {
        match = 0;
        alpha = 255;
    }
} grid[10][10];

/*
 * swap
 * Swaps the row/col of two pieces in the grid
 */
void swap(piece p1, piece p2)
{
    swap(p1.col, p2.col);
    swap(p1.row, p2.row);

    grid[p1.row][p1.col] = p1;
    grid[p2.row][p2.col] = p2;
}

/*****************************************************
 * Leaderboard Data
 *****************************************************/
vector<pair<string, int>> leaderboardData;
Sprite leaderboardScreen;

/*
 * loadLeaderboard
 * Loads existing leaderboard data from a text file
 */
void loadLeaderboard(const string &fileName) {
    leaderboardData.clear();
    ifstream file(fileName);
    if (file.is_open()) {
        string name;
        int score;
        while (file >> name >> score) {
            leaderboardData.emplace_back(name, score);
        }
        file.close();
    }
}

/*
 * saveLeaderboard
 * Saves leaderboard data in descending order
 */
void saveLeaderboard(const string &fileName) {
    sort(leaderboardData.begin(), leaderboardData.end(),
         [](auto &a, auto &b) {
             return a.second > b.second; // Descending by score
         });
    ofstream file(fileName);
    if (file.is_open()) {
        for (auto &entry : leaderboardData) {
            file << entry.first << " " << entry.second << "\n";
        }
        file.close();
    }
}

/*
 * displayLeaderboard
 * Displays the leaderboard screen for 3 seconds
 */
void displayLeaderboard(RenderWindow &app, Text &leaderboardText, Font &myfont, Texture &leaderboardTexture)
{
    // Load existing data
    loadLeaderboard("leaderboard.txt");

    // Ensure leaderboard screen uses the correct texture
    Sprite leaderboardScreen;
    leaderboardScreen.setTexture(leaderboardTexture);

    // We’ll show the leaderboard screen for 3 seconds
    sf::Clock displayClock;
    while (displayClock.getElapsedTime().asSeconds() < 3.f) {
        Event leaderboardEvent;
        while (app.pollEvent(leaderboardEvent)) {
            if (leaderboardEvent.type == Event::Closed) {
                app.close();
                return;
            }
        }
        // Draw the background
        app.clear();
        app.draw(leaderboardScreen);

        // Display the entries from top to bottom
        float yOffset = 150.f;
        for (auto &entry : leaderboardData) {
            stringstream ss;
            ss << entry.first << " - " << entry.second;

            leaderboardText.setFont(myfont);
            leaderboardText.setString(ss.str());
            leaderboardText.setCharacterSize(25);
            leaderboardText.setFillColor(Color::White);
            leaderboardText.setPosition(310, yOffset);
            app.draw(leaderboardText);

            yOffset += 30;
            if (yOffset > 400) break;
        }
        app.display();
    }
}

string playerName = "";

/*****************************************************
 * main
 *****************************************************/
int main() {
    srand(time(0));
    Clock clock;
    int mcounter = 20;      // moves counter
    int scounter = 0;       // score counter
    float second = 120;     // time counter
    int hcounter = 1160;    // highscore counter
    int level = 1;          // level counter
    int levelUpThreshold = 100; // Points required to level up

    // Create the main window
    RenderWindow app(VideoMode(740, 480), "");
    app.setFramerateLimit(60);

    // Textures
    Texture t1, t2, t3, menuTexture, levelTexture,
            gameOverTexture, winTexture, pauseTexture,
            nameScreenTexture, leaderboardTexture;

    t1.loadFromFile("sprites/back.png");
    t2.loadFromFile("sprites/tiles.png");
    t3.loadFromFile("sprites/cursor.png");
    menuTexture.loadFromFile("sprites/menu.png");
    levelTexture.loadFromFile("sprites/level.png");
    gameOverTexture.loadFromFile("sprites/gameOver.png");
    winTexture.loadFromFile("sprites/win.png");
    pauseTexture.loadFromFile("sprites/pause.png");
    nameScreenTexture.loadFromFile("sprites/nameScreen.png");
    leaderboardTexture.loadFromFile("sprites/leaderboard.png");

    // Fonts and Text objects
    Font font, myfont;
    Text txt1, txt2, txt3, txt4, txt5, txt6, txt7,
         txt8, txt9, txt10, txt11;

    // Sprites
    Sprite background(t1),
           gems(t2),
           menu(menuTexture),
           levelPage(levelTexture),
           gameOver(gameOverTexture),
           win(winTexture),
           pauseScreen(pauseTexture),
           nameScreen(nameScreenTexture),
           leaderboardScreen(leaderboardTexture);

    /*****************************************************
     * Menu Page Logic
     *****************************************************/
    bool showMenu = true;  // Flag to determine whether to display the menu
    Event menuEvent;
    while (showMenu) {
        app.clear();
        app.draw(menu);
        app.display();

        while (app.pollEvent(menuEvent)) {
            if (menuEvent.type == Event::Closed) app.close();
            if (menuEvent.type == Event::KeyPressed) {
                if (menuEvent.key.code == Keyboard::Num1) {
                    // Start the game
                    showMenu = false;
                } else if (menuEvent.key.code == Keyboard::Num2) {
                    // Exit the game
                    app.close();
                    return 0;
                }
            }
        }
    }
    
    bool showNameScreen = true; // Flag to display the name screen
    Event nameScreenEvent;

    /*****************************************************
     * Name Screen Logic
     *****************************************************/
    while (showNameScreen) {
        app.clear();
        app.draw(nameScreen); // Display the name screen background

        while (app.pollEvent(nameScreenEvent)) {
            if (nameScreenEvent.type == Event::Closed) app.close();

            if (nameScreenEvent.type == Event::TextEntered) {
                char enteredChar = static_cast<char>(nameScreenEvent.text.unicode);

                if (enteredChar == '\b') {
                    // Handle backspace
                    if (!playerName.empty()) playerName.pop_back();
                } else if (enteredChar == '\r') {
                    // Handle Enter key
                    if (!playerName.empty()) {
                        showNameScreen = false; // Proceed to the level selection screen
                    }
                } else if (playerName.size() < 15 && isprint(enteredChar)) {
                    // Add valid printable characters
                    playerName += enteredChar;
                }
            }
        }

        // Display prompt and entered name
        Text promptText, playerNameText;
        
        if (!myfont.loadFromFile("arial.ttf")) {
            std::cout << "Error loading font\n";
            return -1; // Exit if the font is not loaded
        }

        // Set the font, size, color, and position for the "Enter Your Name" prompt
        promptText.setFont(myfont);
        promptText.setString("Enter Your Name");
        promptText.setCharacterSize(30);
        promptText.setFillColor(Color::White);
        promptText.setPosition(240, 200);

        // Set the font, size, color, and position for the player's name
        playerNameText.setFont(myfont);
        playerNameText.setString(playerName);
        playerNameText.setCharacterSize(25);
        playerNameText.setFillColor(Color::Cyan);
        playerNameText.setPosition(330, 235);

        // Draw the text on the screen
        app.draw(promptText);
        app.draw(playerNameText);

        app.display();
    }

    /*****************************************************
     * Level Selection Logic
     *****************************************************/
    bool selectLevel = true;
    Event levelEvent;
    while (selectLevel) {
        app.clear();
        app.draw(levelPage);
        app.display();

        while (app.pollEvent(levelEvent)) {
            if (levelEvent.type == Event::Closed) app.close();
            if (levelEvent.type == Event::KeyPressed) {
                if (levelEvent.key.code == Keyboard::Num1) {
                    // Select Level 1
                    mcounter = 10;
                    selectLevel = false;
                } else if (levelEvent.key.code == Keyboard::Num2) {
                    // Select Level 2
                    second = 60;
                    selectLevel = false;
                }
            }
        }
    }

    /*****************************************************
     * Initialize Grid
     *****************************************************/
    for (int i = 1; i <= 8; i++) {
        for (int j = 1; j <= 8; j++) {
            grid[i][j].kind = rand() % 7; // For only one new piece
            grid[i][j].row = i;          // displays rows in the grid
            grid[i][j].col = j;          // displays columns in the grid
            grid[i][j].x = j * ts;       // The tiles stay in place after a match
            grid[i][j].y = i * ts;
        }
    }

    int x, y, x0, y0;
    int click = 0;
    Vector2i pos;
    bool isSwap = false;
    bool isMoving = false;

    // Adding Music
    Music music;
    if (!music.openFromFile("music.ogg")) {
        cout << "ME";
    }
    music.setPosition(0, 1, 7);
    music.setPitch(1.2);
    music.setVolume(1000);
    music.setLoop(true);
    music.play();
    
    bool isPaused = false;

    /*****************************************************
     * Main Game Loop
     *****************************************************/
    while (app.isOpen()) {
        float time = clock.getElapsedTime().asSeconds();
        clock.restart();
        second -= time;

        Event e;
        while (app.pollEvent(e)) {
            if (e.type == Event::Closed) app.close();

            if (e.type == Event::MouseButtonPressed) {
                if (e.mouseButton.button == sf::Mouse::Left) {
                    if (!isSwap && !isMoving) {
                        click++;
                    }
                    pos = Mouse::getPosition(app) - offset;
                }
            }
            // Pause functionality
            if (e.type == Event::KeyPressed && e.key.code == Keyboard::P) {
                // Press 'P' to pause
                isPaused = true;
            }
        }

        /*
         * Handle pause screen
         * While paused, show the pause screen and check for events
         */
        while (isPaused) {
            app.clear();
            app.draw(pauseScreen);
            app.display();

            Event pauseEvent;
            while (app.pollEvent(pauseEvent)) {
                if (pauseEvent.type == Event::Closed) {
                    app.close();
                    return 0;
                }
                if (pauseEvent.type == Event::KeyPressed) {
                    if (pauseEvent.key.code == Keyboard::Num1) {
                        // Resume game
                        isPaused = false;
                    } else if (pauseEvent.key.code == Keyboard::Num2) {
                        // Exit game
                        app.close();
                        return 0;
                    }
                }
            }
        }

        /*
         * End conditions: moves used up or timer ends
         */
        if (mcounter <= 0 || second <= 0) {
            bool isWin = scounter >= 500; // Determine win or lose based on score

            // Draw the game over or win screen
            app.clear();
            if (isWin) {
                app.draw(win);
            } else {
                app.draw(gameOver);
            }
            app.display();

            // Wait for a few seconds before proceeding
            sf::Clock delayClock;
            while (delayClock.getElapsedTime().asSeconds() < 3.0f) {
                Event delayEvent;
                while (app.pollEvent(delayEvent)) {
                    if (delayEvent.type == Event::Closed) {
                        app.close();
                        return 0;
                    }
                }
            }

            // If the player won, load and add new score, then save
            if (isWin) {
                loadLeaderboard("leaderboard.txt");
                leaderboardData.emplace_back(playerName, scounter);
                saveLeaderboard("leaderboard.txt");

                // Display the updated leaderboard
                displayLeaderboard(app, txt1, myfont, leaderboardTexture);
            } else {
                // Show the leaderboard without adding a new score
                displayLeaderboard(app, txt1, myfont, leaderboardTexture);
            }

            app.close(); // Close the app after displaying the leaderboard screen
        }

        // Adding font for Output
        if (!myfont.loadFromFile("roman.ttf")) cout << "HD";
        if (!font.loadFromFile("arial.ttf")) cout << "MH";

        // Score Counter
        stringstream ss;
        ss << scounter;
        txt1.setFont(myfont);
        txt1.setString(ss.str());
        txt1.setCharacterSize(25);
        txt1.setFillColor(Color::Cyan);
        txt1.setPosition(595, 150);

        // Score Heading
        txt5.setFont(font);
        txt5.setString("SCORE");
        txt5.setCharacterSize(25);
        txt5.setFillColor(Color::Cyan);
        txt5.setPosition(565, 120);

        // Moves Counter
        stringstream mm;
        mm << mcounter;
        txt2.setFont(myfont);
        txt2.setString(mm.str());
        txt2.setCharacterSize(25);
        txt2.setFillColor(Color::Cyan);
        txt2.setPosition(605, 250);

        // Moves Heading
        txt6.setFont(font);
        txt6.setString("MOVES");
        txt6.setCharacterSize(25);
        txt6.setFillColor(Color::Cyan);
        txt6.setPosition(565, 220);

        // Time Counter
        stringstream tt;
        tt << second;
        txt4.setFont(myfont);
        txt4.setString(tt.str());
        txt4.setCharacterSize(25);
        txt4.setFillColor(Color::Cyan);
        txt4.setPosition(570, 340);

        // Time Heading
        txt7.setFont(font);
        txt7.setString("TIME");
        txt7.setCharacterSize(25);
        txt7.setFillColor(Color::Cyan);
        txt7.setPosition(575, 310);

        // Update level based on score
        if (scounter >= level * levelUpThreshold) {
            level++;
            levelUpThreshold += 50; 
        }

        // Mouse Click
        if (click == 1) {
            x0 = pos.x / ts + 1; 
            y0 = pos.y / ts + 1; 
        }

        if (click == 2) {
            x = pos.x / ts + 1;
            y = pos.y / ts + 1;

            if (abs(x - x0) + abs(y - y0) == 1) {
                swap(grid[y0][x0], grid[y][x]);
                isSwap = true;
                click = 0;
                mcounter -= 1;
            } else {
                click = 1;
            }
        }

        // Identifying Same Block
        for (int i = 1; i <= 8; i++) {
            for (int j = 1; j <= 8; j++) {
                if (grid[i][j].kind == grid[i + 1][j].kind)
                    if (grid[i][j].kind == grid[i - 1][j].kind)
                        for (int n = -1; n <= 1; n++) {
                            grid[i + n][j].match++;
                        }

                if (grid[i][j].kind == grid[i][j + 1].kind)
                    if (grid[i][j].kind == grid[i][j - 1].kind)
                        for (int n = -1; n <= 1; n++) {
                            grid[i][j + n].match++;
                        }
            }
        }

        // Moving Animation
        isMoving = false;
        for (int i = 1; i <= 8; i++) {
            for (int j = 1; j <= 8; j++) {
                piece &p = grid[i][j];
                int dx, dy;
                for (int n = 0; n < 4; n++) {
                    dx = p.x - p.col * ts;
                    dy = p.y - p.row * ts;

                    if (dx) p.x -= dx / abs(dx);
                    if (dy) p.y -= dy / abs(dy);
                }
                if (dx || dy) {
                    isMoving = 1;
                }
            }
        }

        // Deleting Animation
        if (!isMoving) {
            for (int i = 1; i <= 8; i++) {
                for (int j = 1; j <= 8; j++) {
                    if (grid[i][j].match) {
                        if (grid[i][j].alpha > 10) {
                            grid[i][j].alpha -= 10;
                            isMoving = true;
                        }
                    }
                }
            }
        }

        // Score Calculation
        int score = 0;
        for (int i = 1; i <= 8; i++) {
            for (int j = 1; j <= 8; j++) {
                score += grid[i][j].match;
            }
        }

        // No Match -> revert swap
        if (isSwap && !isMoving) {
            if (!score) {
                swap(grid[y0][x0], grid[y][x]);
                isSwap = 0;
            }
        }

        // Update Grid
        if (!isMoving) {
            for (int i = 8; i > 0; i--) {
                for (int j = 1; j <= 8; j++) {
                    if (grid[i][j].match) {
                        for (int n = i; n > 0; n--) {
                            if (!grid[n][j].match) {
                                swap(grid[n][j], grid[i][j]);
                            }
                        }
                    }
                }
            }

            for (int j = 1; j <= 8; j++) {
                for (int i = 8, n = 0; i > 0; i--) {
                    if (grid[i][j].match) {
                        scounter += 10;
                        grid[i][j].kind = rand() % 7;
                        grid[i][j].y = -ts * n++;
                        grid[i][j].match = 0;
                        grid[i][j].alpha = 255;
                    }
                }
            }
        }

        // Drawing function
        app.draw(background);
        for (int i = 1; i <= 8; i++) {
            for (int j = 1; j <= 8; j++) {
                piece p = grid[i][j];
                gems.setTextureRect(IntRect(p.kind * 49, 0, 49, 49));
                gems.setColor(Color(255, 255, 255, p.alpha));
                gems.setPosition(p.x, p.y);
                gems.move(offset.x - ts, offset.y - ts);
                app.draw(gems);
            }
        }

        // Draw UI
        app.draw(txt1);
        app.draw(txt2);
        app.draw(txt4);
        app.draw(txt5);
        app.draw(txt6);
        app.draw(txt7);
        // app.draw(levelText);

        app.display();
    }
    return 0;
}

